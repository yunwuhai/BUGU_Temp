#ifndef __0_0_TRANS_5_PWR_H__
#define __0_0_TRANS_5_PWR_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "../sub/0_0_0_SubTrans_0_STM32F401CC/inc/0_0_0_SubTrans_0_STM32F401CC_4_PWR.h"

void Func_0_0_Trans_5_PWR_0_MCU_Configure_0_Basic();

#ifdef __cplusplus
}
#endif

#endif