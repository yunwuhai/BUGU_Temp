#include "../inc/0_0_Trans_5_PWR.h"

void Func_0_0_Trans_5_PWR_0_MCU_Configure_0_Basic()
{
    Func_0_0_0_SubTrans_0_STM32F401CC_4_PWR_0_LL_PWR_SetRegulVoltageScaling_0_Extern(Object_DataEnum_0_0_0_SubTrans_0_STM32F401CC_4_PWR_0_LL_PWR_REGU_VOLTAGE_0_LL_PWR_REGU_VOLTAGE_SCALE2);
    return;
}