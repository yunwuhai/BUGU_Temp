#include "../inc/0_0_Trans_2_CLK.h"

void Func_0_0_Trans_2_CLK_0_PLL_ConfigDomain_SYS_0_Basic(uint32_t IFormParam_DataEnum_0_Source, uint32_t IFormParam_DataEnum_1_PLLM, uint32_t IFormParam_U32_2_PLLN, uint32_t IFormParam_DataEnum_3_PLLP_R)
{
    Func_0_0_0_SubTrans_0_STM32F401CC_1_CLK_4_LL_RCC_PLL_ConfigDomain_SYS_0_Extern(IFormParam_DataEnum_0_Source, IFormParam_DataEnum_1_PLLM, IFormParam_U32_2_PLLN, IFormParam_DataEnum_3_PLLP_R);
    return;
}