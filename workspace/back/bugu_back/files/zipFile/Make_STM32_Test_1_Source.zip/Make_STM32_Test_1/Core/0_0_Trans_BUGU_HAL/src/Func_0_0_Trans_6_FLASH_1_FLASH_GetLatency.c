#include "../inc/0_0_Trans_6_FLASH.h"

void Func_0_0_Trans_6_FLASH_1_FLASH_GetLatency_0_Basic(uint32_t* OFormParam_DetaEnum_0_Latency)
{
    Func_0_0_0_SubTrans_0_STM32F401CC_5_FLASH_1_LL_FLASH_GetLatency_0_Extern(OFormParam_DetaEnum_0_Latency);
    return;
}