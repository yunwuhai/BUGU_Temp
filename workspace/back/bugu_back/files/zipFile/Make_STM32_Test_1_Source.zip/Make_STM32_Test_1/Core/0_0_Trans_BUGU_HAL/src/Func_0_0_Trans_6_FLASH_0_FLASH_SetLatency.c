#include "../inc/0_0_Trans_6_FLASH.h"

void Func_0_0_Trans_6_FLASH_0_FLASH_SetLatency_0_Basic(uint32_t IFormParam_DataEnum_0_Latency)
{
    Func_0_0_0_SubTrans_0_STM32F401CC_5_FLASH_0_LL_FLASH_SetLatency_0_Extern(IFormParam_DataEnum_0_Latency);
    return;
}