#ifndef __0_0_TRANS_6_FLASH_H__
#define __0_0_TRANS_6_FLASH_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "../sub/0_0_0_SubTrans_0_STM32F401CC/inc/0_0_0_SubTrans_0_STM32F401CC_5_FLASH.h"

void Func_0_0_Trans_6_FLASH_0_FLASH_SetLatency_0_Basic(uint32_t IFormParam_DataEnum_0_Latency);
void Func_0_0_Trans_6_FLASH_1_FLASH_GetLatency_0_Basic(uint32_t* OFormParam_DetaEnum_0_Latency);
void Func_0_0_Trans_6_FLASH_2_MCU_Configure_0_Basic();

#ifdef __cplusplus
}
#endif

#endif