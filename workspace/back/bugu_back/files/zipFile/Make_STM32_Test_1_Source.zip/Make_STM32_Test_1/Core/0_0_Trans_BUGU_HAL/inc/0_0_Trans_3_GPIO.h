#ifndef __0_0_TRANS_3_GPIO_H__
#define __0_0_TRANS_3_GPIO_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "../sub/0_0_0_SubTrans_0_STM32F401CC/inc/0_0_0_SubTrans_0_STM32F401CC_1_CLK.h"

void Func_0_0_Trans_3_GPIO_0_ClockEnable_0_Basic(uint32_t IFormParam_DataEnum_0_Periphs);

#ifdef __cplusplus
}
#endif

#endif