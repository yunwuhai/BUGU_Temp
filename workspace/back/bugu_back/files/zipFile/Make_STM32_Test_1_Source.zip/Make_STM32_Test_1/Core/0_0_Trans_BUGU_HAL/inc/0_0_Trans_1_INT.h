#ifndef __0_0_TRANS_1_INT_H__
#define __0_0_TRANS_1_INT_H__

#ifdef __cplusplus
extern "C" {
#endif
/*************
引用文件，当调用内部下级组件的类时，使用相对路径
*************/
#include "../sub/0_0_0_SubTrans_0_STM32F401CC/inc/0_0_0_SubTrans_0_STM32F401CC_0_INT.h"

void Func_0_0_Trans_1_INT_0_MCU_Configure_0_Basic();

#ifdef __cplusplus
}
#endif

#endif