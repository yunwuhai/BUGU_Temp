#include "../inc/0_0_Trans_3_GPIO.h"

void Func_0_0_Trans_3_GPIO_0_ClockEnable_0_Basic(uint32_t IFormParam_DataEnum_0_Periphs)
{
    Func_0_0_0_SubTrans_0_STM32F401CC_1_CLK_2_LL_AHB1_GRP1_EnableClock_0_Extern(IFormParam_DataEnum_0_Periphs);
    return;
}