#include "../inc/0_0_Trans_2_CLK.h"

void Func_0_0_Trans_2_CLK_6_SetPrescaler_0_AHB(uint32_t IFormParam_DataEnum_0_Prescaler)
{
    Func_0_0_0_SubTrans_0_STM32F401CC_1_CLK_7_LL_RCC_SetAHBPrescaler_0_Extern(IFormParam_DataEnum_0_Prescaler);
    return;
}

void Func_0_0_Trans_2_CLK_6_SetPrescaler_1_APB1(uint32_t IFormParam_DataEnum_0_Prescaler)
{
    Func_0_0_0_SubTrans_0_STM32F401CC_1_CLK_8_LL_RCC_SetAPB1Prescaler_0_Extern(IFormParam_DataEnum_0_Prescaler);
    return;
}

void Func_0_0_Trans_2_CLK_6_SetPrescaler_2_APB2(uint32_t IFormParam_DataEnum_0_Prescaler)
{
    Func_0_0_0_SubTrans_0_STM32F401CC_1_CLK_9_LL_RCC_SetAPB2Prescaler_0_Extern(IFormParam_DataEnum_0_Prescaler);
    return;
}