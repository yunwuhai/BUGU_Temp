#include "../inc/0_Main.h"

int main(int argc, char** argv)
{
  Func_0_0_Trans_0_SYS_0_MCU_Configure_0_Basic();
  Func_0_0_Trans_2_CLK_9_Init_0_Basic();
  Func_1_BSP_0_CLK_0_Init_0();
  Func_0_0_Trans_4_USART_0_Enable_0_Basic();
  while(1)
  {

  }
  return 0;
}