#ifndef __1_BSP_0_CLK_H__
#define __1_BSP_0_CLK_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "Core/0_0_Trans_BUGU_HAL/inc/0_0_Trans_3_GPIO.h"

void Func_1_BSP_0_CLK_0_Init_0();

#ifdef __cplusplus
}
#endif

#endif