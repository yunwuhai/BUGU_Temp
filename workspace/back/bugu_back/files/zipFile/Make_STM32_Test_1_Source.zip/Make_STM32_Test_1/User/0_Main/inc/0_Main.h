#ifndef __0_MAIN_H__
#define __0_MAIN_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "Core/0_0_Trans_BUGU_HAL/inc/0_0_Trans_0_SYS.h"
#include "Core/0_0_Trans_BUGU_HAL/inc/0_0_Trans_2_CLK.h"
#include "User/1_BSP/inc/1_BSP_0_CLK.h"
#include "Core/0_0_Trans_BUGU_HAL/inc/0_0_Trans_4_USART.h"

#ifdef __cplusplus
}
#endif

#endif
